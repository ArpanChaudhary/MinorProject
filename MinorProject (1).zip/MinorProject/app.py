import pickle
from flask import Flask, request, render_template
import numpy as np

app = Flask(__name__)

# Load the model and scaler
with open('LR_CardioML.pkl', 'rb') as model_file, open('scaler.pkl', 'rb') as scaler_file:
    model = pickle.load(model_file)
    scaler = pickle.load(scaler_file)

# Home page route
@app.route('/')
def home():
    return render_template('home.html')

# Prediction form page route
@app.route('/predict', methods=['GET', 'POST'])  # Accept both GET and POST
def predict_page():
    if request.method == 'POST':
        # Retrieve form data
        data = [
            float(request.form['id']),
            float(request.form['age']),
            float(request.form['gender']),
            float(request.form['height']),
            float(request.form['weight']),
            float(request.form['ap_hi']),
            float(request.form['ap_lo']),
            float(request.form['cholesterol']),
            float(request.form['gluc']),
            float(request.form['smoke']),
            float(request.form['alco']),
            float(request.form['active'])
        ]

        # Transform the input data using the scaler
        final_input = scaler.transform(np.array(data).reshape(1, -1))
        
        # Make a prediction using the model
        output = model.predict(final_input)[0]
        
        # Result text
        result_text = "You are a heart patient" if output == 1 else "You are not a heart patient"
        
        # Render result page with the prediction text
        return render_template('result.html', prediction_text=result_text)
    
    return render_template('predict.html')  # Render the form if GET request

if __name__ == "__main__":
    app.run(debug=True)
